📦 Как задеплоить Telegram-бота на Render:

1. Залей этот проект в GitHub (создай репозиторий и загрузи файлы).
2. Перейди на https://dashboard.render.com
3. Нажми "New Web Service" → "Deploy from GitHub"
4. Выбери репозиторий с этим проектом.
5. Render сам найдёт файл render.yaml и применит конфигурацию.
6. Добавь переменные окружения:
   - TELEGRAM_TOKEN = токен от BotFather
   - OPENAI_API_KEY = ключ от OpenAI
   - ALLOWED_TELEGRAM_USER_IDS = твой Telegram ID (необязательно)
7. Нажми Deploy — бот будет в онлайне 24/7.

🔥 Удачи, Мешок рядом!
